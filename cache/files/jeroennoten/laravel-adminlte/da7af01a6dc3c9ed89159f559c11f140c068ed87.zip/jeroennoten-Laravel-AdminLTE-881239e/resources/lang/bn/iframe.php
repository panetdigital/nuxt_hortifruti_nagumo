<?php

return [

    /*
    |--------------------------------------------------------------------------
    | IFrame Mode Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the AdminLTE IFrame mode blade
    | layout. You are free to modify these language lines according to your
    | application's requirements.
    |
    */

    'btn_close' => 'বন্ধ করুন',
    'btn_close_active' => 'একটিভ গুলো বন্ধ করুন',
    'btn_close_all' => 'সব বন্ধ করুন',
    'btn_close_all_other' => 'অন্য সবকিছু বন্ধ করুন',
    'tab_empty' => 'কোন ট্যাব নির্বাচন করা হয়নি!',
    'tab_home' => 'হোম',
    'tab_loading' => 'ট্যাব লোড হচ্ছে',

];
