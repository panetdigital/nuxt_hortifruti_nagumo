<?php

return [

    'main_navigation'               => 'MENU PRINCIPALE',
    'blog'                          => 'Blog',
    'pages'                         => 'Pagine',
    'account_settings'              => 'IMPOSTAZIONI ACCOUNT',
    'profile'                       => 'Profilo',
    'change_password'               => 'Modifica Password',
    'multilevel'                    => 'Multi Livello',
    'level_one'                     => 'Livello 1',
    'level_two'                     => 'Livello 2',
    'level_three'                   => 'Livello 3',
    'labels'                        => 'ETICHETTE',
    'important'                     => 'Importante',
    'warning'                       => 'Avvertimento',
    'information'                   => 'Informazione',
];
